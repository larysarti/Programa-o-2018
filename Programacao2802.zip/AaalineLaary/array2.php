<?php


//herois dois 

$herois= array('Batman','Thor','Hulk','Flash','Jaspion','Alinoxa','Yunguiton','Miss Fortune' );

//print_r($herois);

//$a=1;
//$tamanho = sizeof($herois);

//	for( $i=0; $i<$tamanho; $i++ ){
//			print( $a."º lugar: " .$herois[$i].".\n");
//			$a++;
//	}
//or

foreach ($herois as $i => $heroi) {
	print ($i + 1 . "º lugar: $heroi \n");
}