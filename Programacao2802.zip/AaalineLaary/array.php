<?php
//Heróis

$herois=array();
$i=0;


/*while($i<5){
print("Digite o nome de 5 heróis:\n");
$herois[]= fgets(STDIN);

$i++;
}

print_r($herois);

*/

for($i=0; $i <5; $i++){

	print("Digite o nome de 5 heróis:\n");
	$herois[]= fgets(STDIN);

}