<?php

$numero1= array(4,7,10);

$simbolo= array('+','-','*');

$numero2= array (19,20,3);

$result=0;

	for($i=0; $i<=2; $i++){
		
		for($a=0; $a<3; $a++){
			
			if($simbolo[$a]==$simbolo[0]){
				$result= $numero1[$i] + $numero2[$i];
				print($numero1[$i]. "+" .$numero2[$i]. "=" .$result."\n");

			}elseif($simbolo[$a]==$simbolo[1]){
				$result= $numero1[$i] - $numero2[$i];
				print($numero1[$i]. "-" .$numero2[$i]. "=" .$result."\n");
			
			}elseif($simbolo[$a]==$simbolo[2]){
				$result= $numero1[$i] * $numero2[$i];
				print($numero1[$i]. "*" .$numero2[$i]. "=" .$result."\n");

			}

		}
	}
